from Mindblocks.model.value_type.index.index_value_model import IndexValueModel


class IndexTypeModel:

    def initialize_value_model(self, language=None):
        return IndexValueModel()