from Mindblocks.model.component_type.component_type_model import ComponentTypeModel
import tensorflow as tf

from Mindblocks.model.execution_graph.execution_component_value_model import ExecutionComponentValueModel


class Softmax(ComponentTypeModel):

    name = "Softmax"
    in_sockets = ["input"]
    out_sockets = ["output"]
    languages = ["tensorflow"]

    def initialize_value(self, value_dictionary, language):
        return SoftmaxValue()

    def execute(self, execution_component, input_dictionary, value, output_value_models, mode):
        lengths = input_dictionary["input"].get_lengths()
        output_value_models["output"].assign(tf.nn.softmax(input_dictionary["input"].get_value()),
                                             length_list=lengths)
        return output_value_models

    def build_value_type_model(self, input_types, value, mode):
        output_type = input_types["input"].copy()
        output_type.set_dimension(-1, 1)
        return {"output": output_type}

class SoftmaxValue(ExecutionComponentValueModel):

    pass