class ComponentNotFoundException(Exception):

    """
    Exception raised when an undeclared component is referenced.
    """